package sample.project.studentservice.studentServiceTest;

import org.junit.jupiter.api.Test;

import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
class StudentServiceApplicationTests {

    @Test
    public void contextLoads() {

    }
}