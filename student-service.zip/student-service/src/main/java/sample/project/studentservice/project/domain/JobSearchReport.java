package sample.project.studentservice.project.domain;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

public class JobSearchReport {

    private int id;

    private boolean isJobSearching;

    private int coachId;

    public JobSearchReport(int id, boolean isJobSearching, int coachId) {
        this.id = id;
        this.isJobSearching = isJobSearching;
        this.coachId = coachId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public boolean isJobSearching() {
        return isJobSearching;
    }

    public void setJobSearching(boolean jobSearching) {
        isJobSearching = jobSearching;
    }

    public int getCoachId() {
        return coachId;
    }

    public void setCoachId(int coachId) {
        this.coachId = coachId;
    }
}
