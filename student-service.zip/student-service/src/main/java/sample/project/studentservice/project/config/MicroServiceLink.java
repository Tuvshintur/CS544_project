package sample.project.studentservice.project.config;

import org.springframework.stereotype.Component;

@Component
public class MicroServiceLink {

    private String jobSearchReport ="http://localhost:8085";
    public String jobSearchReport (Integer studentId){
        return jobSearchReport+"/jobSearchReport/"+studentId;
    }
}
